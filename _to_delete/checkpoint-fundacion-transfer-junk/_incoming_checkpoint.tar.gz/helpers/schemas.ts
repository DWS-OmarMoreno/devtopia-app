import { object, string } from "yup";

export const LoginSchema = object().shape({
  email: string()
    .email("This field must be an email")
    .required("Email is required"),
  password: string().required("Password is required"),
});

export const InvitarUsuarioSchema = object().shape({
  nombre_completo: string().required("El nombre es obligatorio"),
  email: string()
    .email("Debe ser un correo válido")
    .required("El correo es obligatorio"),
  rol_id: string().required("Debes elegir un rol"),
});
