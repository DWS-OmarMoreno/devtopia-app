// FORMS

export type LoginFormType = {
  email: string;
  password: string;
};

export type InvitarUsuarioFormType = {
  nombre_completo: string;
  email: string;
  rol_id: string;
};
