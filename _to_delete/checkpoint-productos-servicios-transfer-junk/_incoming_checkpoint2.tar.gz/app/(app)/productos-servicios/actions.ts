"use server";

import { revalidatePath } from "next/cache";
import { cookies } from "next/headers";
import { createClient } from "@/utils/supabase/server";
import { getUsuarioActual, usuarioTienePermiso } from "@/lib/auth/getUsuarioActual";
import type { Accion } from "@/lib/rbac";
import type { TablesInsert, TablesUpdate } from "@/utils/database.types";

export type ResultadoAccion = { ok: true } | { ok: false; error: string };

const RUTA = "/productos-servicios";

/**
 * Todas las acciones de este módulo comparten el mismo patrón: permiso a
 * nivel de módulo (la matriz `permisos` seed no define sublistas específicas
 * para PRODUCTOS_SERVICIOS todavía — ver seed.sql — así que el chequeo aquí
 * y las políticas RLS generadas por fn_crear_politicas_rls() coinciden). Se
 * pasa `sublista` de todas formas (mismo valor que usa la política RLS de
 * cada tabla) para que si en el futuro se agrega una fila específica en la
 * matriz, este chequeo del lado UI la respete sin cambios de código.
 */
async function requerirPermiso(accion: Accion, sublista: string | null) {
  const usuario = await getUsuarioActual();
  if (!usuarioTienePermiso(usuario, "PRODUCTOS_SERVICIOS", accion, sublista ?? undefined)) {
    return { usuario: null, error: "No tienes permiso para realizar esta acción." } as const;
  }
  return { usuario, error: null } as const;
}

function numeroOpcional(valor: FormDataEntryValue | null): number | null {
  if (valor === null) return null;
  const texto = String(valor).trim();
  if (!texto) return null;
  const n = Number(texto);
  return Number.isFinite(n) ? n : null;
}

function textoOpcional(valor: FormDataEntryValue | null): string | null {
  if (valor === null) return null;
  const texto = String(valor).trim();
  return texto ? texto : null;
}

// =============================================================================
// Categorías de servicio
// =============================================================================

export async function crearCategoria(formData: FormData): Promise<ResultadoAccion> {
  const { usuario, error } = await requerirPermiso("crear", null);
  if (!usuario) return { ok: false, error: error! };

  const fila: TablesInsert<"categorias_servicio"> = {
    empresa_id: usuario.perfil.empresa_id,
    nombre: String(formData.get("nombre") ?? "").trim(),
    descripcion: textoOpcional(formData.get("descripcion")),
    categoria_padre_id: textoOpcional(formData.get("categoria_padre_id")),
  };

  if (!fila.nombre) return { ok: false, error: "El nombre es obligatorio." };

  const supabase = createClient(cookies());
  const { error: errorDb } = await supabase.from("categorias_servicio").insert(fila);
  if (errorDb) return { ok: false, error: errorDb.message };

  revalidatePath(RUTA);
  return { ok: true };
}

export async function actualizarCategoria(id: string, formData: FormData): Promise<ResultadoAccion> {
  const { usuario, error } = await requerirPermiso("editar", null);
  if (!usuario) return { ok: false, error: error! };

  const cambios: TablesUpdate<"categorias_servicio"> = {
    nombre: String(formData.get("nombre") ?? "").trim(),
    descripcion: textoOpcional(formData.get("descripcion")),
    categoria_padre_id: textoOpcional(formData.get("categoria_padre_id")),
  };

  if (cambios.categoria_padre_id === id) {
    return { ok: false, error: "Una categoría no puede ser su propia categoría padre." };
  }
  if (!cambios.nombre) return { ok: false, error: "El nombre es obligatorio." };

  const supabase = createClient(cookies());
  const { error: errorDb } = await supabase.from("categorias_servicio").update(cambios).eq("id", id);
  if (errorDb) return { ok: false, error: errorDb.message };

  revalidatePath(RUTA);
  return { ok: true };
}

export async function cambiarEstadoCategoria(id: string, activo: boolean): Promise<ResultadoAccion> {
  const { usuario, error } = await requerirPermiso("editar", null);
  if (!usuario) return { ok: false, error: error! };

  const supabase = createClient(cookies());
  const { error: errorDb } = await supabase.from("categorias_servicio").update({ activo }).eq("id", id);
  if (errorDb) return { ok: false, error: errorDb.message };

  revalidatePath(RUTA);
  return { ok: true };
}

// =============================================================================
// Roles y tarifa
// =============================================================================

export async function crearRolTarifa(formData: FormData): Promise<ResultadoAccion> {
  const { usuario, error } = await requerirPermiso("crear", "roles_tarifa");
  if (!usuario) return { ok: false, error: error! };

  const tarifaEstandar = numeroOpcional(formData.get("tarifa_hora_estandar"));
  const monedaId = String(formData.get("moneda_id") ?? "").trim();
  const nombreRol = String(formData.get("nombre_rol") ?? "").trim();

  if (!nombreRol) return { ok: false, error: "El nombre del rol es obligatorio." };
  if (tarifaEstandar === null || tarifaEstandar <= 0) {
    return { ok: false, error: "La tarifa estándar debe ser un número mayor a 0." };
  }
  if (!monedaId) return { ok: false, error: "Debes elegir una moneda." };

  const fila: TablesInsert<"catalogo_roles_tarifa"> = {
    empresa_id: usuario.perfil.empresa_id,
    nombre_rol: nombreRol,
    nivel_experiencia: textoOpcional(formData.get("nivel_experiencia")),
    tarifa_hora_estandar: tarifaEstandar,
    tarifa_hora_costo_referencia: numeroOpcional(formData.get("tarifa_hora_costo_referencia")),
    moneda_id: monedaId,
    vigente_desde: String(formData.get("vigente_desde") || new Date().toISOString().slice(0, 10)),
    vigente_hasta: textoOpcional(formData.get("vigente_hasta")),
  };

  const supabase = createClient(cookies());
  const { error: errorDb } = await supabase.from("catalogo_roles_tarifa").insert(fila);
  if (errorDb) return { ok: false, error: errorDb.message };

  revalidatePath(RUTA);
  return { ok: true };
}

export async function actualizarRolTarifa(id: string, formData: FormData): Promise<ResultadoAccion> {
  const { usuario, error } = await requerirPermiso("editar", "roles_tarifa");
  if (!usuario) return { ok: false, error: error! };

  const tarifaEstandar = numeroOpcional(formData.get("tarifa_hora_estandar"));
  if (tarifaEstandar === null || tarifaEstandar <= 0) {
    return { ok: false, error: "La tarifa estándar debe ser un número mayor a 0." };
  }

  const cambios: TablesUpdate<"catalogo_roles_tarifa"> = {
    nombre_rol: String(formData.get("nombre_rol") ?? "").trim(),
    nivel_experiencia: textoOpcional(formData.get("nivel_experiencia")),
    tarifa_hora_estandar: tarifaEstandar,
    tarifa_hora_costo_referencia: numeroOpcional(formData.get("tarifa_hora_costo_referencia")),
    moneda_id: String(formData.get("moneda_id") ?? "").trim(),
    vigente_desde: String(formData.get("vigente_desde") || ""),
    vigente_hasta: textoOpcional(formData.get("vigente_hasta")),
  };

  const supabase = createClient(cookies());
  const { error: errorDb } = await supabase.from("catalogo_roles_tarifa").update(cambios).eq("id", id);
  if (errorDb) return { ok: false, error: errorDb.message };

  revalidatePath(RUTA);
  return { ok: true };
}

export async function cambiarEstadoRolTarifa(id: string, activo: boolean): Promise<ResultadoAccion> {
  const { usuario, error } = await requerirPermiso("editar", "roles_tarifa");
  if (!usuario) return { ok: false, error: error! };

  const supabase = createClient(cookies());
  const { error: errorDb } = await supabase.from("catalogo_roles_tarifa").update({ activo }).eq("id", id);
  if (errorDb) return { ok: false, error: errorDb.message };

  revalidatePath(RUTA);
  return { ok: true };
}

// =============================================================================
// SLA: planes y niveles
// =============================================================================

export async function crearPlanSla(formData: FormData): Promise<ResultadoAccion> {
  const { usuario, error } = await requerirPermiso("crear", "sla");
  if (!usuario) return { ok: false, error: error! };

  const nombre = String(formData.get("nombre") ?? "").trim();
  if (!nombre) return { ok: false, error: "El nombre del plan es obligatorio." };

  const fila: TablesInsert<"sla_planes"> = {
    empresa_id: usuario.perfil.empresa_id,
    nombre,
    descripcion: textoOpcional(formData.get("descripcion")),
  };

  const supabase = createClient(cookies());
  const { error: errorDb } = await supabase.from("sla_planes").insert(fila);
  if (errorDb) return { ok: false, error: errorDb.message };

  revalidatePath(RUTA);
  return { ok: true };
}

export async function actualizarPlanSla(id: string, formData: FormData): Promise<ResultadoAccion> {
  const { usuario, error } = await requerirPermiso("editar", "sla");
  if (!usuario) return { ok: false, error: error! };

  const cambios: TablesUpdate<"sla_planes"> = {
    nombre: String(formData.get("nombre") ?? "").trim(),
    descripcion: textoOpcional(formData.get("descripcion")),
  };
  if (!cambios.nombre) return { ok: false, error: "El nombre del plan es obligatorio." };

  const supabase = createClient(cookies());
  const { error: errorDb } = await supabase.from("sla_planes").update(cambios).eq("id", id);
  if (errorDb) return { ok: false, error: errorDb.message };

  revalidatePath(RUTA);
  return { ok: true };
}

export async function cambiarEstadoPlanSla(id: string, activo: boolean): Promise<ResultadoAccion> {
  const { usuario, error } = await requerirPermiso("editar", "sla");
  if (!usuario) return { ok: false, error: error! };

  const supabase = createClient(cookies());
  const { error: errorDb } = await supabase.from("sla_planes").update({ activo }).eq("id", id);
  if (errorDb) return { ok: false, error: errorDb.message };

  revalidatePath(RUTA);
  return { ok: true };
}

export async function crearNivelSla(slaPlanId: string, formData: FormData): Promise<ResultadoAccion> {
  const { usuario, error } = await requerirPermiso("crear", "sla");
  if (!usuario) return { ok: false, error: error! };

  const tiempoRespuesta = numeroOpcional(formData.get("tiempo_respuesta_horas"));
  const tiempoResolucion = numeroOpcional(formData.get("tiempo_resolucion_horas"));
  const horarioCobertura = String(formData.get("horario_cobertura") ?? "").trim();
  const severidad = String(formData.get("severidad") ?? "").trim();

  if (!severidad) return { ok: false, error: "Debes elegir una severidad." };
  if (tiempoRespuesta === null || tiempoResolucion === null) {
    return { ok: false, error: "Los tiempos de respuesta y resolución son obligatorios." };
  }
  if (!horarioCobertura) return { ok: false, error: "El horario de cobertura es obligatorio." };

  const fila: TablesInsert<"sla_niveles"> = {
    sla_plan_id: slaPlanId,
    severidad,
    tiempo_respuesta_horas: tiempoRespuesta,
    tiempo_resolucion_horas: tiempoResolucion,
    horario_cobertura: horarioCobertura,
    penalizacion_incumplimiento: textoOpcional(formData.get("penalizacion_incumplimiento")),
    penalizacion_pct_credito: numeroOpcional(formData.get("penalizacion_pct_credito")),
  };

  const supabase = createClient(cookies());
  const { error: errorDb } = await supabase.from("sla_niveles").insert(fila);
  if (errorDb) {
    const mensaje = errorDb.message.includes("duplicate key")
      ? `Ese plan ya tiene un nivel definido para la severidad ${severidad}.`
      : errorDb.message;
    return { ok: false, error: mensaje };
  }

  revalidatePath(RUTA);
  return { ok: true };
}

export async function eliminarNivelSla(id: string): Promise<ResultadoAccion> {
  const { usuario, error } = await requerirPermiso("eliminar", "sla");
  if (!usuario) return { ok: false, error: error! };

  const supabase = createClient(cookies());
  const { error: errorDb } = await supabase.from("sla_niveles").delete().eq("id", id);
  if (errorDb) return { ok: false, error: errorDb.message };

  revalidatePath(RUTA);
  return { ok: true };
}

// =============================================================================
// Catálogo de servicios
// =============================================================================

export async function crearServicio(formData: FormData): Promise<ResultadoAccion> {
  const { usuario, error } = await requerirPermiso("crear", null);
  if (!usuario) return { ok: false, error: error! };

  const codigo = String(formData.get("codigo") ?? "").trim();
  const nombre = String(formData.get("nombre") ?? "").trim();
  const tipoServicio = String(formData.get("tipo_servicio") ?? "").trim();
  const unidadMedida = String(formData.get("unidad_medida") ?? "").trim();
  const tarifaEstandar = numeroOpcional(formData.get("tarifa_estandar"));
  const monedaId = String(formData.get("moneda_id") ?? "").trim();

  if (!codigo) return { ok: false, error: "El código es obligatorio." };
  if (!nombre) return { ok: false, error: "El nombre es obligatorio." };
  if (!tipoServicio) return { ok: false, error: "Debes elegir un tipo de servicio." };
  if (!unidadMedida) return { ok: false, error: "Debes elegir una unidad de medida." };
  if (tarifaEstandar === null || tarifaEstandar <= 0) {
    return { ok: false, error: "La tarifa estándar debe ser un número mayor a 0." };
  }
  if (!monedaId) return { ok: false, error: "Debes elegir una moneda." };

  const fila: TablesInsert<"catalogo_servicios"> = {
    empresa_id: usuario.perfil.empresa_id,
    codigo,
    nombre,
    descripcion: textoOpcional(formData.get("descripcion")),
    categoria_id: textoOpcional(formData.get("categoria_id")),
    tipo_servicio: tipoServicio,
    unidad_medida: unidadMedida,
    tarifa_estandar: tarifaEstandar,
    moneda_id: monedaId,
    sla_plan_id: textoOpcional(formData.get("sla_plan_id")),
    requiere_aprobacion_cotizacion: formData.get("requiere_aprobacion_cotizacion") === "true",
    fecha_vigencia_desde: textoOpcional(formData.get("fecha_vigencia_desde")),
    fecha_vigencia_hasta: textoOpcional(formData.get("fecha_vigencia_hasta")),
  };

  const supabase = createClient(cookies());
  const { error: errorDb } = await supabase.from("catalogo_servicios").insert(fila);
  if (errorDb) {
    const mensaje = errorDb.message.includes("duplicate key")
      ? `Ya existe un servicio con el código "${codigo}".`
      : errorDb.message;
    return { ok: false, error: mensaje };
  }

  revalidatePath(RUTA);
  return { ok: true };
}

export async function actualizarServicio(id: string, formData: FormData): Promise<ResultadoAccion> {
  const { usuario, error } = await requerirPermiso("editar", null);
  if (!usuario) return { ok: false, error: error! };

  const tarifaEstandar = numeroOpcional(formData.get("tarifa_estandar"));
  if (tarifaEstandar === null || tarifaEstandar <= 0) {
    return { ok: false, error: "La tarifa estándar debe ser un número mayor a 0." };
  }

  const cambios: TablesUpdate<"catalogo_servicios"> = {
    codigo: String(formData.get("codigo") ?? "").trim(),
    nombre: String(formData.get("nombre") ?? "").trim(),
    descripcion: textoOpcional(formData.get("descripcion")),
    categoria_id: textoOpcional(formData.get("categoria_id")),
    tipo_servicio: String(formData.get("tipo_servicio") ?? "").trim(),
    unidad_medida: String(formData.get("unidad_medida") ?? "").trim(),
    tarifa_estandar: tarifaEstandar,
    moneda_id: String(formData.get("moneda_id") ?? "").trim(),
    sla_plan_id: textoOpcional(formData.get("sla_plan_id")),
    requiere_aprobacion_cotizacion: formData.get("requiere_aprobacion_cotizacion") === "true",
    fecha_vigencia_desde: textoOpcional(formData.get("fecha_vigencia_desde")),
    fecha_vigencia_hasta: textoOpcional(formData.get("fecha_vigencia_hasta")),
  };

  const supabase = createClient(cookies());
  const { error: errorDb } = await supabase.from("catalogo_servicios").update(cambios).eq("id", id);
  if (errorDb) {
    const mensaje = errorDb.message.includes("duplicate key")
      ? `Ya existe un servicio con ese código.`
      : errorDb.message;
    return { ok: false, error: mensaje };
  }

  revalidatePath(RUTA);
  return { ok: true };
}

export async function cambiarEstadoServicio(id: string, activo: boolean): Promise<ResultadoAccion> {
  const { usuario, error } = await requerirPermiso("editar", null);
  if (!usuario) return { ok: false, error: error! };

  const supabase = createClient(cookies());
  const { error: errorDb } = await supabase.from("catalogo_servicios").update({ activo }).eq("id", id);
  if (errorDb) return { ok: false, error: errorDb.message };

  revalidatePath(RUTA);
  return { ok: true };
}
