// FORMS

export type LoginFormType = {
  email: string;
  password: string;
};

export type InvitarUsuarioFormType = {
  nombre_completo: string;
  email: string;
  rol_id: string;
};

// --- Productos y Servicios ---------------------------------------------

export type CategoriaServicioFormType = {
  nombre: string;
  descripcion: string;
  categoria_padre_id: string;
};

export type RolTarifaFormType = {
  nombre_rol: string;
  nivel_experiencia: string;
  tarifa_hora_estandar: string;
  tarifa_hora_costo_referencia: string;
  moneda_id: string;
  vigente_desde: string;
  vigente_hasta: string;
};

export type PlanSlaFormType = {
  nombre: string;
  descripcion: string;
};

export type NivelSlaFormType = {
  severidad: string;
  tiempo_respuesta_horas: string;
  tiempo_resolucion_horas: string;
  horario_cobertura: string;
  penalizacion_incumplimiento: string;
  penalizacion_pct_credito: string;
};

export type ServicioFormType = {
  codigo: string;
  nombre: string;
  descripcion: string;
  categoria_id: string;
  tipo_servicio: string;
  unidad_medida: string;
  tarifa_estandar: string;
  moneda_id: string;
  sla_plan_id: string;
  requiere_aprobacion_cotizacion: boolean;
  fecha_vigencia_desde: string;
  fecha_vigencia_hasta: string;
};
