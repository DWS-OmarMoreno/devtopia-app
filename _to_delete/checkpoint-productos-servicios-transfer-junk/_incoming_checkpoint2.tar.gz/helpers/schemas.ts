import { object, string, number, boolean } from "yup";

export const LoginSchema = object().shape({
  email: string()
    .email("This field must be an email")
    .required("Email is required"),
  password: string().required("Password is required"),
});

export const InvitarUsuarioSchema = object().shape({
  nombre_completo: string().required("El nombre es obligatorio"),
  email: string()
    .email("Debe ser un correo válido")
    .required("El correo es obligatorio"),
  rol_id: string().required("Debes elegir un rol"),
});

// --- Productos y Servicios ---------------------------------------------

export const CategoriaServicioSchema = object().shape({
  nombre: string().required("El nombre es obligatorio"),
  descripcion: string().nullable(),
  categoria_padre_id: string().nullable(),
});

export const RolTarifaSchema = object().shape({
  nombre_rol: string().required("El nombre del rol es obligatorio"),
  nivel_experiencia: string().nullable(),
  tarifa_hora_estandar: number()
    .typeError("Debe ser un número")
    .positive("Debe ser mayor a 0")
    .required("La tarifa estándar es obligatoria"),
  tarifa_hora_costo_referencia: number()
    .typeError("Debe ser un número")
    .min(0, "No puede ser negativo")
    .nullable(),
  moneda_id: string().required("Debes elegir una moneda"),
  vigente_desde: string().required("La fecha de vigencia es obligatoria"),
  vigente_hasta: string().nullable(),
});

export const PlanSlaSchema = object().shape({
  nombre: string().required("El nombre del plan es obligatorio"),
  descripcion: string().nullable(),
});

export const NivelSlaSchema = object().shape({
  severidad: string().required("Debes elegir una severidad"),
  tiempo_respuesta_horas: number()
    .typeError("Debe ser un número")
    .positive("Debe ser mayor a 0")
    .required("El tiempo de respuesta es obligatorio"),
  tiempo_resolucion_horas: number()
    .typeError("Debe ser un número")
    .positive("Debe ser mayor a 0")
    .required("El tiempo de resolución es obligatorio"),
  horario_cobertura: string().required("El horario de cobertura es obligatorio"),
  penalizacion_incumplimiento: string().nullable(),
  penalizacion_pct_credito: number()
    .typeError("Debe ser un número")
    .min(0)
    .max(100, "Debe ser un porcentaje entre 0 y 100")
    .nullable(),
});

export const ServicioSchema = object().shape({
  codigo: string().required("El código es obligatorio"),
  nombre: string().required("El nombre es obligatorio"),
  descripcion: string().nullable(),
  categoria_id: string().nullable(),
  tipo_servicio: string().required("Debes elegir un tipo de servicio"),
  unidad_medida: string().required("Debes elegir una unidad de medida"),
  tarifa_estandar: number()
    .typeError("Debe ser un número")
    .positive("Debe ser mayor a 0")
    .required("La tarifa estándar es obligatoria"),
  moneda_id: string().required("Debes elegir una moneda"),
  sla_plan_id: string().nullable(),
  requiere_aprobacion_cotizacion: boolean().default(false),
  fecha_vigencia_desde: string().nullable(),
  fecha_vigencia_hasta: string().nullable(),
});
