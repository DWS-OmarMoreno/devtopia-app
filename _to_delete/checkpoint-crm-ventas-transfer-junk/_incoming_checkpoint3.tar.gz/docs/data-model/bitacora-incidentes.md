# Bitácora de Incidentes — Modelo de Datos

Registro corto de síntoma → causa → solución para cambios estructurales, siguiendo el
protocolo del proyecto (§3, "Cambios estructurales bajo protocolo"). Agregar una entrada
nueva cada vez que se depure algo no obvio relacionado con el esquema, para no repetir el
diagnóstico la próxima vez que se parezca. Entradas más recientes primero.

## Plantilla

```
### AAAA-MM-DD — Título corto del incidente

- **Síntoma**: qué se observó.
- **Causa**: raíz real del problema (no el síntoma).
- **Solución**: qué se cambió y en qué migración/commit.
- **Prevención** (opcional): cómo evitar que se repita.
```

## Incidentes durante la construcción del frontend

### 2026-08-25 — Nombre de compañeros invisible en pantallas colaborativas (ejecutivo comercial, "quién registró")

- **Síntoma**: en el módulo CRM y Ventas, las columnas "ejecutivo comercial" (Cuentas y
  Oportunidades) y "registró" (bitácora de seguimiento) aparecían vacías ("—") cada vez que
  el dato pertenecía a OTRO usuario distinto del que tenía la sesión abierta — cada usuario
  solo veía su propio nombre en esas columnas. No lanzaba ningún error: PostgREST
  simplemente omite (`null`) un embed (`perfiles_usuario(nombre_completo)`) bloqueado por
  RLS, así que era fácil no notarlo probando con un solo usuario.
- **Causa**: la política `perfiles_usuario_self_select_pol`
  (`20260825000009_rls_lectura_basica_propia.sql`) solo permite a cada usuario leer SU
  PROPIA fila de `perfiles_usuario`. Verificado en Postgres local con dos usuarios reales
  (Comercial y Administrador) simulados: la actividad registrada por Administrador se veía
  con `registrado_por = null` al consultar como Comercial.
- **Solución**: `20260825000011_rls_perfiles_usuario_visibles_en_empresa.sql` agrega una
  política SELECT aditiva: cualquier usuario autenticado puede leer los perfiles de TODOS
  los usuarios de su propia empresa (`empresa_id = fn_empresa_actual()`), no solo el suyo —
  equivalente a un directorio interno. Verificado que un usuario de OTRA empresa simulada
  sigue sin ver estos perfiles (aislamiento multiempresa intacto), y que tras la migración
  el Comercial ve correctamente `registrado_por = 'Admin Prueba'`.
- **Prevención**: cualquier tabla que se vaya a **embeber** desde otra vía PostgREST (join
  implícito) para mostrar "quién hizo esto" en una pantalla colaborativa necesita una
  política de lectura a nivel de organización (no solo autolectura) desde el diseño de la
  etapa correspondiente — la autolectura sirve para "quién soy yo", no para "quién es mi
  compañero". Revisar este mismo patrón al construir Contratos y Proyectos (recursos
  asignados, aprobadores) y Compras (aprobador interno).

### 2026-08-25 — `fn_generar_consecutivo()` fallaba para cualquier rol que no fuera Administrador

- **Síntoma**: al construir el módulo CRM y Ventas (creación de `oportunidades`, cuyo
  `codigo` se genera con `fn_generar_consecutivo('OPORTUNIDAD', empresa_id)`), un usuario
  con rol Comercial/PM/Desarrollador recibía `Secuencia OPORTUNIDAD no configurada para la
  empresa ...` al crear una oportunidad — aunque la secuencia sí estaba sembrada
  correctamente en `seed.sql`.
- **Causa**: la función, tal como quedó definida en
  `20260825000002_configuracion_general.sql`, es `SECURITY INVOKER` (el valor por defecto):
  corre con los privilegios de quien la llama y hace un `select ... for update` + `update`
  directo sobre `secuencias_numeracion`, tabla protegida por RLS bajo
  `CONFIGURACION`/`editar`. En la matriz sembrada solo Administrador tiene una fila de
  permisos para CONFIGURACION — para cualquier otro rol, RLS bloqueaba silenciosamente el
  `select ... for update` dentro de la función, que entonces reportaba "no encontrado"
  aunque la fila sí existiera. Mismo patrón de "bootstrap circular" que el incidente
  anterior, pero sobre una función en vez de una tabla de sesión.
- **Solución**: `20260825000010_fix_generador_consecutivo_security_definer.sql` cambia la
  función a `SECURITY DEFINER` + `set search_path = public` (mismo patrón ya usado en
  `fn_empresa_actual()`/`fn_tiene_permiso()`), y agrega una verificación explícita
  `p_empresa_id = fn_empresa_actual()` al inicio — necesaria porque SECURITY DEFINER
  bypasea RLS, así que sin ese chequeo cualquier usuario autenticado podría avanzar el
  consecutivo de OTRA empresa pasándole un `p_empresa_id` ajeno. Verificado en Postgres
  local simulando un usuario con rol Comercial: genera `OPP-2026-0001`/`OPP-2026-0002`
  correctamente para su propia empresa, y recibe un error explícito (sin tocar el contador)
  al intentar generar un consecutivo para una empresa ajena.
- **Prevención**: cualquier función `SECURITY DEFINER` que toque una tabla filtrada por
  `empresa_id` debe revalidar la empresa explícitamente en su primera línea — SECURITY
  DEFINER es "todo o nada" respecto a RLS, no hay forma de heredar parcialmente las
  políticas del invocador. Y, en general: cualquier función que la capa de aplicación deba
  poder invocar independientemente del rol de negocio del usuario (numeración de
  documentos, resolución de "quién soy") es candidata a necesitar SECURITY DEFINER desde el
  diseño inicial, no como parche posterior.

### 2026-08-25 — RLS baseline bloqueaba a un usuario la lectura de sus propios datos ("bootstrap" circular)

- **Síntoma**: al construir el hook de sesión del frontend, un usuario con rol distinto de
  Administrador (p. ej. Desarrollador, PM, Comercial) no podía leer ni su propia fila de
  `perfiles_usuario`, ni el nombre de su `empresas`, ni su propia fila de `roles`, ni sus
  propias filas de `permisos` — es decir, la aplicación no podía pintar ni el navbar tras
  iniciar sesión para ningún rol que no fuera Administrador.
- **Causa**: las políticas RLS de `20260825000008_rls_baseline.sql` gatean la lectura de
  esas 4 tablas por `fn_tiene_permiso('CONFIGURACION', 'leer', ...)`, y en la matriz
  sembrada (`seed.sql`) solo el rol Administrador tiene permiso de lectura sobre el módulo
  CONFIGURACION. Un usuario necesita leer su propio perfil/rol/permisos precisamente para
  que la aplicación sepa qué puede hacer — pedirle además el permiso de CONFIGURACION para
  poder leer esos datos es circular.
- **Solución**: `20260825000009_rls_lectura_basica_propia.sql` agrega 4 políticas SELECT
  aditivas (Postgres combina políticas del mismo comando con OR, así que solo amplían
  acceso, nunca lo restringen): cada usuario puede leer su propio `perfiles_usuario`, los
  datos básicos de su propia `empresas`, su propio `roles`, y sus propias filas de
  `permisos`. Verificado en Postgres local simulando un usuario con rol Desarrollador: ve
  exactamente 1 perfil (el suyo), 1 empresa, 1 rol, 3 permisos (los de su rol), y sigue
  viendo 0 filas de `cuentas_clientes` (sin acceso a CRM, como debe ser).
- **Prevención**: cualquier tabla que el frontend necesite leer para saber "quién soy y qué
  puedo hacer" debe tener una política de auto-lectura explícita, independiente de la
  matriz de permisos — nunca asumir que "leer mis propios datos de sesión" está cubierto
  por el mismo permiso que administra esos datos para terceros.

## Incidentes durante el diseño inicial (validados antes de entregar)

### 2026-08-25 — `CREATE OR REPLACE VIEW` fallaba al completar `vista_rentabilidad_proyecto`

- **Síntoma**: al aplicar `20260825000006_compras_subcontratacion.sql` contra Postgres 16,
  falló con `cannot change data type of view column "costo_subcontratacion" from
  numeric(18,2) to numeric`.
- **Causa**: la definición inicial de la vista (migración 04) fijaba la columna como
  `0::numeric(18,2)`, pero el `sum()` de un `numeric(18,2)` en la definición reemplazada
  (migración 05) resuelve a `numeric` sin precisión/escala explícitas. Postgres no permite
  que `CREATE OR REPLACE VIEW` cambie el tipo de una columna existente.
- **Solución**: se agregó un cast explícito `::numeric(18,2)` a las cinco columnas
  calculadas en ambas definiciones de la vista, para que el tipo sea idéntico en las dos
  versiones.
- **Prevención**: toda vista que se vaya a reemplazar más adelante (`create or replace
  view`) debe declarar el tipo exacto (incluida precisión/escala) de cada columna
  calculada desde su primera versión, no confiar en la inferencia automática de tipo.

### 2026-08-25 — Literales UUID inválidos en `seed.sql`

- **Síntoma**: (detectado antes de aplicar, por validación programática) varios UUID de
  ejemplo usaban letras fuera del rango hexadecimal (`r`, `k`, `x`, `o`, `p`), lo que
  Postgres habría rechazado como UUID inválido.
- **Causa**: al generar IDs mnemotécnicos legibles a mano (`...-r1`, `...-e0k01`, etc.) no
  se validó que todos los caracteres fueran dígitos hexadecimales (0-9, a-f).
- **Solución**: se rediseñó la convención a `000000000` + 3 dígitos hexadecimales en el
  último segmento, y se corrió un script de validación (`re.match` contra el patrón
  UUID estándar) sobre todos los archivos `.sql` antes de aplicar cualquier migración.
- **Prevención**: cualquier IDs fijo nuevo en scripts de semilla debe pasar por el mismo
  validador antes de considerarse listo para aplicar. No confiar en revisión visual para
  literales UUID.
