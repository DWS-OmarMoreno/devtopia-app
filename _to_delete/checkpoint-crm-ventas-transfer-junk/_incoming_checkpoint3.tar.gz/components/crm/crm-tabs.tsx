"use client";

import { Tabs, Tab } from "@nextui-org/react";
import type { Tables } from "@/utils/database.types";
import { CuentasPanel, type CuentaConRelaciones } from "./cuentas-panel";
import {
  OportunidadesPanel,
  type OportunidadConRelaciones,
  type SeguimientoConRelaciones,
} from "./oportunidades-panel";

interface Props {
  cuentas: CuentaConRelaciones[];
  contactos: Tables<"contactos">[];
  oportunidades: OportunidadConRelaciones[];
  seguimientos: SeguimientoConRelaciones[];
  monedas: Tables<"monedas">[];
  motivosPerdida: Tables<"catalogos_valores">[];
  usuariosEmpresa: { id: string; nombre_completo: string }[];
  usuarioActualId: string | null;
  puedeCrearCuenta: boolean;
  puedeEditarCuenta: boolean;
  puedeCrearOportunidad: boolean;
  puedeEditarOportunidad: boolean;
}

export function CrmTabs({
  cuentas,
  contactos,
  oportunidades,
  seguimientos,
  monedas,
  motivosPerdida,
  usuariosEmpresa,
  usuarioActualId,
  puedeCrearCuenta,
  puedeEditarCuenta,
  puedeCrearOportunidad,
  puedeEditarOportunidad,
}: Props) {
  return (
    <Tabs aria-label="Secciones de CRM y Ventas" variant="underlined">
      <Tab key="cuentas" title="Cuentas">
        <CuentasPanel
          cuentas={cuentas}
          contactos={contactos}
          monedas={monedas}
          usuariosEmpresa={usuariosEmpresa}
          puedeCrear={puedeCrearCuenta}
          puedeEditar={puedeEditarCuenta}
        />
      </Tab>
      <Tab key="oportunidades" title="Oportunidades">
        <OportunidadesPanel
          oportunidades={oportunidades}
          seguimientos={seguimientos}
          cuentas={cuentas}
          contactos={contactos}
          monedas={monedas}
          motivosPerdida={motivosPerdida}
          usuariosEmpresa={usuariosEmpresa}
          usuarioActualId={usuarioActualId}
          puedeCrear={puedeCrearOportunidad}
          puedeEditar={puedeEditarOportunidad}
        />
      </Tab>
    </Tabs>
  );
}
