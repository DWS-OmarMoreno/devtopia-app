import { cookies } from "next/headers";
import { createClient } from "@/utils/supabase/server";
import { getUsuarioActual, usuarioTienePermiso } from "@/lib/auth/getUsuarioActual";
import { AccesoDenegado } from "@/components/shared/acceso-denegado";
import { CrmTabs } from "@/components/crm/crm-tabs";
import type { CuentaConRelaciones } from "@/components/crm/cuentas-panel";
import type { OportunidadConRelaciones, SeguimientoConRelaciones } from "@/components/crm/oportunidades-panel";

export default async function CrmPage() {
  const usuario = await getUsuarioActual();

  if (!usuarioTienePermiso(usuario, "CRM_VENTAS", "leer")) {
    return <AccesoDenegado />;
  }

  const supabase = createClient(cookies());

  const [
    { data: cuentas },
    { data: contactos },
    { data: oportunidades },
    { data: seguimientos },
    { data: monedas },
    { data: motivosPerdida },
    { data: usuariosEmpresa },
  ] = await Promise.all([
    supabase
      .from("cuentas_clientes")
      .select("*, ejecutivo:perfiles_usuario(nombre_completo)")
      .is("deleted_at", null)
      .order("razon_social", { ascending: true }),
    supabase.from("contactos").select("*").order("nombre", { ascending: true }),
    supabase
      .from("oportunidades")
      .select(
        "*, cuentas_clientes(razon_social), contactos(nombre, apellido), ejecutivo:perfiles_usuario(nombre_completo)"
      )
      .is("deleted_at", null)
      .order("created_at", { ascending: false }),
    supabase
      .from("oportunidades_seguimiento")
      .select("*, perfiles_usuario(nombre_completo)")
      .order("fecha", { ascending: false }),
    supabase.from("monedas").select("*").eq("activa", true).order("codigo_iso", { ascending: true }),
    supabase
      .from("catalogos_valores")
      .select("*")
      .eq("catalogo", "MOTIVO_PERDIDA_OPORTUNIDAD")
      .eq("activo", true)
      .order("orden", { ascending: true }),
    supabase
      .from("perfiles_usuario")
      .select("id, nombre_completo")
      .eq("activo", true)
      .order("nombre_completo", { ascending: true }),
  ]);

  const puedeCrear = usuarioTienePermiso(usuario, "CRM_VENTAS", "crear", "cuentas");
  const puedeEditar = usuarioTienePermiso(usuario, "CRM_VENTAS", "editar", "cuentas");
  const puedeCrearOportunidad = usuarioTienePermiso(usuario, "CRM_VENTAS", "crear", "oportunidades");
  const puedeEditarOportunidad = usuarioTienePermiso(usuario, "CRM_VENTAS", "editar", "oportunidades");

  return (
    <div className="my-10 px-4 lg:px-6 max-w-[95rem] mx-auto w-full flex flex-col gap-4">
      <div>
        <h3 className="text-xl font-semibold">CRM y Ventas</h3>
        <p className="text-default-500 text-sm">
          Cuentas y contactos, y el embudo de oportunidades con su bitácora de
          seguimiento. Las cotizaciones se agregan en una siguiente etapa.
        </p>
      </div>

      <CrmTabs
        cuentas={(cuentas ?? []) as unknown as CuentaConRelaciones[]}
        contactos={contactos ?? []}
        oportunidades={(oportunidades ?? []) as unknown as OportunidadConRelaciones[]}
        seguimientos={(seguimientos ?? []) as unknown as SeguimientoConRelaciones[]}
        monedas={monedas ?? []}
        motivosPerdida={motivosPerdida ?? []}
        usuariosEmpresa={usuariosEmpresa ?? []}
        usuarioActualId={usuario?.id ?? null}
        puedeCrearCuenta={puedeCrear}
        puedeEditarCuenta={puedeEditar}
        puedeCrearOportunidad={puedeCrearOportunidad}
        puedeEditarOportunidad={puedeEditarOportunidad}
      />
    </div>
  );
}
