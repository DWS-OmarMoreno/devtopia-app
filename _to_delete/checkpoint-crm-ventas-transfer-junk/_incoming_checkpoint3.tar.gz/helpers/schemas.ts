import { object, string, number, boolean } from "yup";

export const LoginSchema = object().shape({
  email: string()
    .email("This field must be an email")
    .required("Email is required"),
  password: string().required("Password is required"),
});

export const InvitarUsuarioSchema = object().shape({
  nombre_completo: string().required("El nombre es obligatorio"),
  email: string()
    .email("Debe ser un correo válido")
    .required("El correo es obligatorio"),
  rol_id: string().required("Debes elegir un rol"),
});

// --- Productos y Servicios ---------------------------------------------

export const CategoriaServicioSchema = object().shape({
  nombre: string().required("El nombre es obligatorio"),
  descripcion: string().nullable(),
  categoria_padre_id: string().nullable(),
});

export const RolTarifaSchema = object().shape({
  nombre_rol: string().required("El nombre del rol es obligatorio"),
  nivel_experiencia: string().nullable(),
  tarifa_hora_estandar: number()
    .typeError("Debe ser un número")
    .positive("Debe ser mayor a 0")
    .required("La tarifa estándar es obligatoria"),
  tarifa_hora_costo_referencia: number()
    .typeError("Debe ser un número")
    .min(0, "No puede ser negativo")
    .nullable(),
  moneda_id: string().required("Debes elegir una moneda"),
  vigente_desde: string().required("La fecha de vigencia es obligatoria"),
  vigente_hasta: string().nullable(),
});

export const PlanSlaSchema = object().shape({
  nombre: string().required("El nombre del plan es obligatorio"),
  descripcion: string().nullable(),
});

export const NivelSlaSchema = object().shape({
  severidad: string().required("Debes elegir una severidad"),
  tiempo_respuesta_horas: number()
    .typeError("Debe ser un número")
    .positive("Debe ser mayor a 0")
    .required("El tiempo de respuesta es obligatorio"),
  tiempo_resolucion_horas: number()
    .typeError("Debe ser un número")
    .positive("Debe ser mayor a 0")
    .required("El tiempo de resolución es obligatorio"),
  horario_cobertura: string().required("El horario de cobertura es obligatorio"),
  penalizacion_incumplimiento: string().nullable(),
  penalizacion_pct_credito: number()
    .typeError("Debe ser un número")
    .min(0)
    .max(100, "Debe ser un porcentaje entre 0 y 100")
    .nullable(),
});

export const ServicioSchema = object().shape({
  codigo: string().required("El código es obligatorio"),
  nombre: string().required("El nombre es obligatorio"),
  descripcion: string().nullable(),
  categoria_id: string().nullable(),
  tipo_servicio: string().required("Debes elegir un tipo de servicio"),
  unidad_medida: string().required("Debes elegir una unidad de medida"),
  tarifa_estandar: number()
    .typeError("Debe ser un número")
    .positive("Debe ser mayor a 0")
    .required("La tarifa estándar es obligatoria"),
  moneda_id: string().required("Debes elegir una moneda"),
  sla_plan_id: string().nullable(),
  requiere_aprobacion_cotizacion: boolean().default(false),
  fecha_vigencia_desde: string().nullable(),
  fecha_vigencia_hasta: string().nullable(),
});

// --- CRM y Ventas --------------------------------------------------------

export const CuentaClienteSchema = object().shape({
  razon_social: string().required("La razón social es obligatoria"),
  nombre_comercial: string().nullable(),
  tipo_identificacion: string().required("Debes elegir un tipo de identificación"),
  numero_identificacion: string().required("El número de identificación es obligatorio"),
  cuenta_padre_id: string().nullable(),
  sector_industria: string().nullable(),
  tamano_empresa: string().nullable(),
  sitio_web: string().nullable(),
  direccion_facturacion: string().nullable(),
  ciudad: string().nullable(),
  pais: string().nullable(),
  telefono_principal: string().nullable(),
  email_principal: string().email("Debe ser un correo válido").nullable(),
  moneda_preferida_id: string().nullable(),
  ejecutivo_comercial_id: string().nullable(),
  origen_captacion: string().nullable(),
  estado: string().required(),
  notas: string().nullable(),
});

export const ContactoSchema = object().shape({
  nombre: string().required("El nombre es obligatorio"),
  apellido: string().nullable(),
  cargo: string().nullable(),
  email: string().email("Debe ser un correo válido").nullable(),
  telefono: string().nullable(),
  celular: string().nullable(),
  canal_preferido: string().nullable(),
  es_contacto_principal: boolean().default(false),
  es_firmante_autorizado: boolean().default(false),
  notas: string().nullable(),
});

export const OportunidadSchema = object().shape({
  cuenta_id: string().required("Debes elegir una cuenta"),
  contacto_id: string().nullable(),
  nombre_oportunidad: string().required("El nombre de la oportunidad es obligatorio"),
  descripcion: string().nullable(),
  etapa: string().required(),
  probabilidad_cierre_pct: number()
    .typeError("Debe ser un número")
    .min(0)
    .max(100, "Debe ser un porcentaje entre 0 y 100")
    .nullable(),
  valor_estimado: number().typeError("Debe ser un número").min(0).nullable(),
  moneda_id: string().nullable(),
  fecha_estimada_cierre: string().nullable(),
  motivo_perdida_id: string().nullable(),
  motivo_perdida_detalle: string().nullable(),
  origen_oportunidad: string().nullable(),
  ejecutivo_comercial_id: string().required("Debes elegir un ejecutivo comercial"),
  proxima_accion: string().nullable(),
  fecha_proxima_accion: string().nullable(),
});

export const SeguimientoSchema = object().shape({
  tipo_actividad: string().required("Debes elegir un tipo de actividad"),
  descripcion: string().required("La descripción es obligatoria"),
  resultado: string().nullable(),
});
