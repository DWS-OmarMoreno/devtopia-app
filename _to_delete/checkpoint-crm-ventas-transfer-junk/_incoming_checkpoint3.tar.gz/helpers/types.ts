// FORMS

export type LoginFormType = {
  email: string;
  password: string;
};

export type InvitarUsuarioFormType = {
  nombre_completo: string;
  email: string;
  rol_id: string;
};

// --- Productos y Servicios ---------------------------------------------

export type CategoriaServicioFormType = {
  nombre: string;
  descripcion: string;
  categoria_padre_id: string;
};

export type RolTarifaFormType = {
  nombre_rol: string;
  nivel_experiencia: string;
  tarifa_hora_estandar: string;
  tarifa_hora_costo_referencia: string;
  moneda_id: string;
  vigente_desde: string;
  vigente_hasta: string;
};

export type PlanSlaFormType = {
  nombre: string;
  descripcion: string;
};

export type NivelSlaFormType = {
  severidad: string;
  tiempo_respuesta_horas: string;
  tiempo_resolucion_horas: string;
  horario_cobertura: string;
  penalizacion_incumplimiento: string;
  penalizacion_pct_credito: string;
};

export type ServicioFormType = {
  codigo: string;
  nombre: string;
  descripcion: string;
  categoria_id: string;
  tipo_servicio: string;
  unidad_medida: string;
  tarifa_estandar: string;
  moneda_id: string;
  sla_plan_id: string;
  requiere_aprobacion_cotizacion: boolean;
  fecha_vigencia_desde: string;
  fecha_vigencia_hasta: string;
};

// --- CRM y Ventas --------------------------------------------------------

export type CuentaClienteFormType = {
  razon_social: string;
  nombre_comercial: string;
  tipo_identificacion: string;
  numero_identificacion: string;
  cuenta_padre_id: string;
  sector_industria: string;
  tamano_empresa: string;
  sitio_web: string;
  direccion_facturacion: string;
  ciudad: string;
  pais: string;
  telefono_principal: string;
  email_principal: string;
  moneda_preferida_id: string;
  ejecutivo_comercial_id: string;
  origen_captacion: string;
  estado: string;
  notas: string;
};

export type ContactoFormType = {
  nombre: string;
  apellido: string;
  cargo: string;
  email: string;
  telefono: string;
  celular: string;
  canal_preferido: string;
  es_contacto_principal: boolean;
  es_firmante_autorizado: boolean;
  notas: string;
};

export type OportunidadFormType = {
  cuenta_id: string;
  contacto_id: string;
  nombre_oportunidad: string;
  descripcion: string;
  etapa: string;
  probabilidad_cierre_pct: string;
  valor_estimado: string;
  moneda_id: string;
  fecha_estimada_cierre: string;
  motivo_perdida_id: string;
  motivo_perdida_detalle: string;
  origen_oportunidad: string;
  ejecutivo_comercial_id: string;
  proxima_accion: string;
  fecha_proxima_accion: string;
};

export type SeguimientoFormType = {
  tipo_actividad: string;
  descripcion: string;
  resultado: string;
};
